registerPlugin({
    name: 'BadNick Check',
    version: '1.2',
    description: 'Kicks or Messages People with a Bad Nickname!',
    author: 'Multivitamin <multivitamin.wtf>',
    vars: [
        {
            name: 'badnick',
            title: 'List of Banned Nicknames (Help Script: http://sinus.cat/helpers/badnick/)',
            type: 'multiline'
        },
        {
            name: 'action',
            title: 'What should happen when a Client with a Bad Nickname has been detected?',
            type: 'select',
            options: [
                'Kick',
                'Message'
            ]
        },
        {
            name: 'message',
            title: 'Kick / Warn DEFAULT Message',
            type: 'string',
        },
        {
            name: 'ignore',
            title: 'Comma Seperated List of Groups which should get ignored',
            type: 'string',
        }
    ]
}, function(sinusbot, config) {

    var sinusbot = null

    var event = require("event")
    var engine = require("engine")
    var backend = require("backend")

    var badnicks = []

    //Load the badnick Multiline Variable into a List of Nicks
    if (config.badnick !== undefined) {
        for (var key in config.badnick.split('\n')) {
            //Check for Valid Regex String
            if (config.badnick.split('\n')[key].match(/^[ ]{0,}\/(.{1,})\/([gmixXsuUAJ]{0,10})[ ]{0,}(\->[ ]{0,}(.{1,})|)$/i)) {
                var capture = config.badnick.split('\n')[key].match(/^[ ]{0,}\/(.{1,})\/([gmixXsuUAJ]{0,10})[ ]{0,}(\->[ ]{0,}(.{1,})|)$/i)
                var re = new RegExp(capture[1], capture[2])
                var msg = capture[4]
            //User Probably does not know Regex try to use it anyway
            } else {
                engine.log('Invalid Regex Format detected! > '+config.badnick.split('\n')[key])
                var re = new RegExp(config.badnick.split('\n')[key], 'i')
                var msg = undefined
            }
            badnicks.push([re, msg])
        }
    }

    //Validate for errors in the Config Input
    var action = config.action ? config.action : 0
    var addcomplaint = config.addcomplaint ? config.addcomplaint : 0
    var message = config.message ? config.message : 'Please do not use this Nickname!'
    var ignore = config.ignore ? config.ignore.split(',') : []

    event.on("chat", function (ev) {
        if (ev.client.isSelf()) return
        if (ev.text.match(/^!help ?$/)) {
            ev.client.chat('[b]BAD NICK CHECK[/b] This Bot uses [URL=https://multivitamin.wtf]Multivitamins[/URL] Bad Nick Check Plugin!')
        }
    })

    //Events
    //Event for Client Connect / Move
    event.on('clientMove', function(ev) {
        //Filter all Client Connect Events and check against whitelist
        if (!ev.fromChannel && !whitelist(ev.client)) checkNick(ev.client, ev.clientNick)
    })

    //Do Initial FullCheck on all Clients connected to the Server
    event.on('connect', function(ev) {
        fullCheck()
    })
    fullCheck()

    //Do a check when Client changes its nickname
    event.on('clientNick', function(client) {
        //Check against whitelist
        if (whitelist(client)) return
        checkNick(client)
    })

    //Check if Nick is a Bad Nickname
    function checkNick(client){
        for (var key in badnicks) {
            if (client.nick().match(badnicks[key][0])) {
                engine.log('BadNick detected: '+client.nick()+' via entry \''+badnicks[key][0]+'\'')
                if (action === 1) return client.chat(badnicks[key][1] !== undefined ? badnicks[key][1] : message)
                client.kick(badnicks[key][1] !== undefined ? badnicks[key][1] : message)
            }
        }
    }

    //Check all Nicknames on the Server 
    function fullCheck() {
        //Get a List of all Clients connected to the Server
        backend.getClients()
            .filter(function(client) {
                return !client.isSelf()
            })
            .filter(function(client) {
                return !whitelist(client)
            })
            .forEach(checkNick)
    }

    //Check if User is whitelisted via Ignore Settings
    function whitelist(client) {
        return client.getServerGroups().some(function(group) {
            return ignore.indexOf(group.id()) >= 0
        })
    }

})